package com.example.ejemplo1

import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.tooling.preview.Preview
import com.example.ejemplo1.ui.theme.Ejemplo1Theme
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ejemplo1.pamodels.Alumnoss
import com.example.ejemplo1.pamodels.alumno


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Ejemplo1Theme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    Conversation(alumno)
                }
            }
        }//fin setContent
    }//fin onCreate
}//fin class
@Composable
fun Conversation( datos:List<Alumnoss>) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column() {
            LazyColumn{
                items(datos){
                        message-> Mensaje(message.id,message.nombre,message.dato,message.foto)
                }//fin items
            }//fin LazyColumn
        }//fin Column
    }//fin Surface
}//fin fun
@Composable
fun Mensaje(id:Int,nombre:String,dato:String,foto:Int) {
    Surface() {
        Row ( modifier=Modifier.padding(5.dp)) {
            Image(
                modifier = Modifier
                    //.height(200.dp)
                    .size(100.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, MaterialTheme.colors.secondary, CircleShape),
                painter = painterResource(foto),
                contentDescription = "merry"
            )
            Spacer(modifier = Modifier.width(6.dp) )
            var expandirTexto by remember {
                mutableStateOf(false)
            }
            val surface by animateColorAsState(
                if (expandirTexto) MaterialTheme.colors.primary else MaterialTheme.colors.surface
            )
            Column(modifier = Modifier.clickable { expandirTexto= !expandirTexto }) {
                Text(
                    text = id.toString(),
                    fontSize = 30.sp,
                    color = MaterialTheme.colors.secondaryVariant,
                    style = MaterialTheme.typography.subtitle2)
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    elevation = 1.dp,
                    modifier = Modifier.animateContentSize().padding(1.dp)
                ) {
                    Text(
                        text = nombre,
                        fontSize = 30.sp,
                        color = MaterialTheme.colors.secondaryVariant,
                        modifier = Modifier.padding(all = 4.dp),
                        maxLines = if (expandirTexto) Int.MAX_VALUE else 1,
                        style = MaterialTheme.typography.body2
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    elevation = 1.dp,
                    modifier = Modifier.animateContentSize().padding(1.dp)
                ) {
                    Text(
                        text = dato,
                        modifier = Modifier.padding(all = 4.dp),
                        maxLines = if (expandirTexto) Int.MAX_VALUE else 1,
                        style = MaterialTheme.typography.body2
                    )
                }

            }//fin colum
        }//fin Row
    }//fin surface
}//fin fun

@Preview(
    uiMode = Configuration.UI_MODE_NIGHT_YES,
    showBackground = true,
    showSystemUi = true,
    name="Dark Mode")
@Composable
fun DefaultPreview() {
    Ejemplo1Theme {
        Surface( modifier = Modifier.fillMaxSize()) {
            Column {
                Conversation(alumno)
            }//fin column
        }//fin surface
    }//fin Ejemplo1Theme
}//fin fun
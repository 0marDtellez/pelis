package com.example.ejemplo1.pamodels

data class Alumnoss(
    var id:Int,
    var nombre:String,
    var dato:String,
    var foto:Int

)

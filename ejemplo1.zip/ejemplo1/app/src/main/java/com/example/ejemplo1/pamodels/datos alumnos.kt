package com.example.ejemplo1.pamodels

import com.example.ejemplo1.R

var alumno= listOf(
    Alumnoss(
        id=1,
        nombre="merry",
        dato="Platónn. (en griego antiguo y griego moderno: Πλάτων, Plátōn; en latín: Plato, Platon; Atenas1 o Egina,2 c. 427-347 a. C.)31 fue un filósofo griego seguidor de Sócratesn. 2  y maestro de Aristóteles.4  En 387 a. C. fundó la Academia de Atenas,5 institución que continuaría a lo largo de más de novecientos añosn. 3 y a la que Aristóteles acudiría desde Estagira a estudiar filosofía alrededor del 367 a. C., compartiendo unos veinte años de amistad y trabajo con su maestro.n. ",
        foto= R.drawable.merry,
    ),
    Alumnoss(
        id=2,
        nombre="sanji",
        dato="Platónn. (en griego antiguo y griego moderno: Πλάτων, Plátōn; en latín: Plato, Platon; Atenas1 o Egina,2 c. 427-347 a. C.)31 fue un filósofo griego seguidor de Sócratesn. 2  y maestro de Aristóteles.4  En 387 a. C. fundó la Academia de Atenas,5 institución que continuaría a lo largo de más de novecientos añosn. 3 y a la que Aristóteles acudiría desde Estagira a estudiar filosofía alrededor del 367 a. C., compartiendo unos veinte años de amistad y trabajo con su maestro.n. ",
        foto= R.drawable._c047e7a30cb8a03f4b832bd89170c6c
    ),
    Alumnoss(
        id=3,
        nombre="yamato",
        dato="Platónn. (en griego antiguo y griego moderno: Πλάτων, Plátōn; en latín: Plato, Platon; Atenas1 o Egina,2 c. 427-347 a. C.)31 fue un filósofo griego seguidor de Sócratesn. 2  y maestro de Aristóteles.4  En 387 a. C. fundó la Academia de Atenas,5 institución que continuaría a lo largo de más de novecientos añosn. 3 y a la que Aristóteles acudiría desde Estagira a estudiar filosofía alrededor del 367 a. C., compartiendo unos veinte años de amistad y trabajo con su maestro.n. ",
        foto= R.drawable._42160123_3959792534126935_2236301997264209310_n
    )
)